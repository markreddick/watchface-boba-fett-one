By installing or using this font, you are agree to the Product Usage Agreement:

- This demo font just for PERSONAL USE ONLY. NO COMMERCIAL USE ALLOWED!

- Here is the link to purchase full version and commercial license:
https://slideshootype.com/north-arena-slab-serif-font/

- For Corporate use you have to purchase Corporate license

- If you need a custom license please contact us at
slideshootdesign@gmail.com

- Any donation are very appreciated. Paypal account for donation : https://paypal.me/slideshoot

Please visit our store for more amazing fonts :
https://slideshootype.com

Thank you.